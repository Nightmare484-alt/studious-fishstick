package com.maya.assistant

import com.maya.assistant.voice.GeminiSpeaker
import com.maya.assistant.voice.SentenceSplitter
import com.maya.assistant.ai.GeminiClient
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

class GeminiSpeakerTest {
    @Test fun parsesPcmFromResponse() {
        val pcm = byteArrayOf(1, 2, 3, 4)
        val json = """{"candidates":[{"content":{"parts":[{"inlineData":{"mimeType":"audio/L16;rate=24000","data":"${Base64.getEncoder().encodeToString(pcm)}"}}]}}]}"""
        assertArrayEquals(pcm, GeminiSpeaker.parsePcm(json))
    }

    @Test(expected = IllegalStateException::class)
    fun noAudioThrowsSoFallbackRuns() {
        GeminiSpeaker.parsePcm("""{"candidates":[{"content":{"parts":[{"text":"hi"}]}}]}""")
    }

    @Test fun chunksLongTextOnSentences() {
        val text = (1..60).joinToString(" ") { "This is sentence number $it." }
        val chunks = GeminiSpeaker.chunk(text)
        assertTrue(chunks.size > 1 && chunks.all { it.length <= 700 })
    }

    @Test fun envelopeFollowsLoudnessAndSilenceIsClosedMouth() {
        val w = 100
        val loud = ByteArray(w * 2) { if (it % 2 == 0) 0x00 else 0x40 }       // constant 0x4000
        val quiet = ByteArray(w * 2)                                          // digital silence
        val env = GeminiSpeaker.envelope(loud + quiet, w)
        assertEquals(2, env.size)
        assertEquals(1f, env[0], 0.001f)
        assertEquals(0f, env[1], 0f)
    }

    @Test fun streamChunkWithoutAudioIsIgnored() {
        assertEquals(null, GeminiSpeaker.parsePcmOrNull("""{"usageMetadata":{"totalTokenCount":5}}"""))
    }

    @Test fun firstSentenceIsReleasedBeforeTheReplyFinishes() {
        val sp = SentenceSplitter()
        assertTrue(sp.push("I am fine").isEmpty())
        assertEquals(listOf("I am fine."), sp.push(". How can I"))      // released as soon as the sentence ends
        assertEquals(listOf("How can I help?"), sp.push(" help? ").let { it + sp.flush() })
    }

    @Test fun splitterDoesNotCutDecimalsAndStripsMarkdown() {
        val sp = SentenceSplitter()
        val out = sp.push("It is **3.5** km away. Next") + sp.flush()
        assertEquals(listOf("It is 3.5 km away.", "Next"), out)
    }

    @Test fun streamChunkTextIsExtractedAndThoughtsSkipped() {
        val json = """{"candidates":[{"content":{"parts":[{"text":"plan","thought":true},{"text":"Hello"}]}}]}"""
        assertEquals("Hello", GeminiClient.parseStreamChunk(json))
        assertEquals("", GeminiClient.parseStreamChunk("[DONE]"))
    }
}
