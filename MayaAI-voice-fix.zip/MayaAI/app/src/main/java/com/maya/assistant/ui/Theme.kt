package com.maya.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.maya.assistant.vm.UiError

// ---- Maya design tokens ----
val Navy = Color(0xFF070B1D)
val NavyMid = Color(0xFF0A1028)
val NavyLift = Color(0xFF101936)
val MayaBlue = Color(0xFF2979FF)
val MayaBlueSoft = Color(0xFF398BFF)
val MayaCyan = Color(0xFF00C8FF)
val MayaPurple = Color(0xFF7952FF)
val MayaViolet = Color(0xFF9747FF)
val MayaNeon = Color(0xFFB45CFF)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFC5CDE3)
val TextMuted = Color(0xFF8995B5)
val SuccessGreen = Color(0xFF35D99A)
val ErrorPink = Color(0xFFFF5D75)
val InfoBlue = Color(0xFF6FB1FF)
val CardBg = Color(0xE6101936)
val GlassBg = Color(0xCC0A1028)
val GlassBorder = Color(0x99398BFF)

val MayaGradient: Brush get() = Brush.horizontalGradient(listOf(MayaBlue, MayaPurple, MayaViolet))
val MayaRingGradient: Brush get() = Brush.sweepGradient(listOf(MayaCyan, MayaBlue, MayaViolet, MayaNeon, MayaCyan))

val ButtonShape = RoundedCornerShape(16.dp)
val ButtonHeight = 48.dp

@Composable
fun MayaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = MayaBlueSoft,
            onPrimary = Color.White,
            primaryContainer = MayaPurple,
            onPrimaryContainer = Color.White,
            secondary = MayaViolet,
            onSecondary = Color.White,
            tertiary = MayaCyan,
            background = Navy,
            onBackground = TextPrimary,
            surface = NavyMid,
            onSurface = TextPrimary,
            surfaceVariant = NavyLift,
            onSurfaceVariant = TextSecondary,
            surfaceContainerLowest = Navy,
            surfaceContainerLow = NavyMid,
            surfaceContainer = NavyMid,
            surfaceContainerHigh = NavyLift,
            surfaceContainerHighest = NavyLift,
            outline = MayaBlueSoft.copy(alpha = 0.7f),
            outlineVariant = Color(0xFF26335F),
            error = ErrorPink,
            onError = Color.White,
        ),
        content = content,
    )
}

fun UiError.message(): String = when (this) {
    UiError.MISSING_KEY -> "I need an API key first. Open Settings and paste your key."
    UiError.UNAUTHORIZED -> "The API key was rejected. Check it in Settings."
    UiError.RATE_LIMITED -> "Google's API says this model's request limit was reached."
    UiError.OVERLOADED -> "The AI service is busy. Please try again shortly."
    UiError.BAD_REQUEST -> "The request was rejected. Check the model name in Settings."
    UiError.SERVER -> "The AI service had a problem. Please try again."
    UiError.NETWORK -> "I couldn't reach the internet. Check your connection and try again."
    UiError.TIMEOUT -> "That took too long. Please try again."
    UiError.BAD_RESPONSE -> "I got a reply I couldn't read. Please try again."
    UiError.UNKNOWN -> "Something went wrong. Please try again."
    UiError.MIC_DENIED -> "Microphone permission was denied. You can still type to me with the keyboard button."
    UiError.MIC_BLOCKED -> "Microphone access is blocked. Enable it in the app's system settings, or type to me."
    UiError.SPEECH_UNAVAILABLE -> "Speech recognition isn't available on this device. You can type to me instead."
    UiError.SPEECH_NO_MATCH -> "I didn't catch that. Tap the mic and try again."
    UiError.SPEECH_NETWORK -> "Speech recognition needs a connection right now. Try again or type to me."
    UiError.SPEECH_BUSY -> "The speech service is busy. Try again in a moment."
    UiError.SPEECH_OTHER -> "Voice input failed. Try again or type to me."
    UiError.CAPTURE_DENIED -> "Screen sharing wasn't allowed, so I didn't capture anything."
    UiError.CAPTURE_FAILED -> "I couldn't capture the screen. Some apps block screenshots."
    UiError.NO_CAMERA_APP -> "No camera app was found on this device."
    UiError.PHOTO_FAILED -> "I couldn't read that photo. Please try again."
    UiError.FILE_FAILED -> "I couldn't read that file. Pick a plain text file."
    UiError.APP_FAILED -> "I couldn't open that app."
}
