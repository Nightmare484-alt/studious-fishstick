package com.maya.assistant.ai

import com.maya.assistant.data.Role
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.util.Base64
import kotlin.math.ceil
import kotlin.random.Random

/**
 * Minimal Google Gemini API (Google AI Studio key) client, no third-party HTTP library.
 * The key is sent in the `x-goog-api-key` header, never in the URL, so it can't leak via logs.
 */
class GeminiClient(
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta",
) : ChatClient {

    override suspend fun send(request: ChatRequest): String {
        if (request.apiKey.isBlank()) throw ChatException(ChatError.MISSING_KEY)
        if (request.model.isBlank()) throw ChatException(ChatError.BAD_REQUEST)
        val url = "$baseUrl/models/${URLEncoder.encode(normalizeModelId(request.model), "UTF-8")}:generateContent"
        val body = buildBody(request)
        val timeout = if (request.webSearch) 90_000 else 60_000
        // Retry only temporary failures (429 per-minute, 500/503), at most MAX_RETRIES times, and never wait longer than
        // MAX_AUTO_WAIT_MS between attempts, so a real limit is reported instead of being hammered.
        var attempt = 0
        while (true) {
            try {
                return parseResponse(call("POST", url, request.apiKey, body, timeout))
            } catch (e: ChatException) {
                val wait = retryDelayMs(e, attempt) ?: throw e
                attempt++
                delay(wait)
            }
        }
    }

    /**
     * Streams the reply over SSE so the first words (and the first spoken sentence) arrive after ~1 s instead of
     * after the whole answer is generated. Falls back to the normal request if streaming fails before any text.
     */
    override suspend fun sendStreaming(request: ChatRequest, onDelta: (String) -> Unit): String {
        if (request.apiKey.isBlank()) throw ChatException(ChatError.MISSING_KEY)
        if (request.model.isBlank()) throw ChatException(ChatError.BAD_REQUEST)
        val url = "$baseUrl/models/${URLEncoder.encode(normalizeModelId(request.model), "UTF-8")}:streamGenerateContent?alt=sse"
        val body = buildBody(request)
        val full = StringBuilder()
        try {
            withContext(Dispatchers.IO) {
                val conn = URL(url).openConnection() as HttpURLConnection
                val watcher = launch { try { awaitCancellation() } finally { conn.disconnect() } }
                try {
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 10_000
                    conn.readTimeout = if (request.webSearch) 90_000 else 30_000
                    conn.setRequestProperty("x-goog-api-key", request.apiKey)
                    conn.setRequestProperty("content-type", "application/json")
                    conn.doOutput = true
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    if (code !in 200..299) {
                        val text = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                        val info = parseError(text, conn.getHeaderField("Retry-After"))
                        throw ChatException(mapStatus(code, text), null, info.retryAfterSec, info.message, info.daily)
                    }
                    conn.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                        while (true) {
                            val line = r.readLine() ?: break
                            if (!line.startsWith("data:")) continue
                            val piece = parseStreamChunk(line.removePrefix("data:").trim())
                            if (piece.isNotEmpty()) { full.append(piece); onDelta(piece) }
                        }
                    }
                } catch (e: ChatException) {
                    ensureActive(); throw e
                } catch (e: SocketTimeoutException) {
                    ensureActive(); throw ChatException(ChatError.TIMEOUT, e)
                } catch (e: IOException) {
                    ensureActive(); throw ChatException(ChatError.NETWORK, e)
                } finally {
                    watcher.cancel(); conn.disconnect()
                }
            }
        } catch (e: ChatException) {
            // Nothing delivered yet -> use the proven non-streaming path (with its retries) instead of failing.
            if (full.isEmpty() && (e.error == ChatError.NETWORK || e.error == ChatError.TIMEOUT || e.error == ChatError.BAD_REQUEST)) {
                return send(request).also(onDelta)
            }
            if (full.isEmpty()) throw e
        }
        val out = full.toString().trim()
        if (out.isEmpty()) return send(request).also(onDelta)
        return out
    }

    override suspend fun listModels(apiKey: String): List<ModelInfo> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw ChatException(ChatError.MISSING_KEY)
        val all = mutableListOf<ModelInfo>()
        var token: String? = null
        var pages = 0
        do {
            val url = "$baseUrl/models?pageSize=1000" +
                (token?.let { "&pageToken=" + URLEncoder.encode(it, "UTF-8") } ?: "")
            val body = call("GET", url, apiKey, null, 20_000)
            all += parseModels(body)
            token = try { JSONObject(body).optString("nextPageToken").ifBlank { null } } catch (e: JSONException) { null }
        } while (token != null && ++pages < 5)
        all.distinctBy { it.id }.sortedBy { it.id }
    }

    /**
     * One HTTP round trip. Blocking [HttpURLConnection] I/O ignores coroutine cancellation, so a watcher child
     * disconnects the socket when this coroutine is cancelled; otherwise a superseded request would still run to
     * completion on Google's side and count against the quota.
     */
    private suspend fun call(method: String, url: String, apiKey: String, body: String?, readTimeoutMs: Int): String =
        withContext(Dispatchers.IO) {
            val conn = URL(url).openConnection() as HttpURLConnection
            val watcher = launch { try { awaitCancellation() } finally { conn.disconnect() } }
            try {
                roundTrip(conn, method, apiKey, body, readTimeoutMs)
            } catch (e: ChatException) {
                ensureActive() // cancelled while in flight: surface cancellation, not a bogus network error
                throw e
            } finally {
                watcher.cancel()
                conn.disconnect()
            }
        }

    private fun roundTrip(conn: HttpURLConnection, method: String, apiKey: String, body: String?, readTimeoutMs: Int): String {
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15_000
            conn.readTimeout = readTimeoutMs
            conn.setRequestProperty("x-goog-api-key", apiKey)
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("content-type", "application/json")
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val info = parseError(text, conn.getHeaderField("Retry-After"))
                throw ChatException(mapStatus(code, text), null, info.retryAfterSec, info.message, info.daily)
            }
            return text
        } catch (e: ChatException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw ChatException(ChatError.TIMEOUT, e)
        } catch (e: IOException) {
            throw ChatException(ChatError.NETWORK, e)
        }
    }

    companion object {
        const val MAX_OUTPUT_TOKENS = 2048
        const val MAX_RETRIES = 2
        const val MAX_AUTO_WAIT_MS = 15_000L

        class ErrorInfo(val message: String?, val retryAfterSec: Int?, val daily: Boolean)

        /** Pulls the provider's message, requested wait (header or RetryInfo "37s") and daily-quota flag from an error. */
        fun parseError(body: String, retryAfterHeader: String? = null): ErrorInfo {
            var message: String? = null
            var retry: Int? = retryAfterHeader?.trim()?.toIntOrNull()?.coerceAtLeast(0)
            try {
                val err = JSONObject(body).optJSONObject("error")
                message = err?.optString("message")?.takeIf { it.isNotBlank() }?.take(240)
                val details = err?.optJSONArray("details")
                if (details != null && retry == null) {
                    for (i in 0 until details.length()) {
                        val rd = details.optJSONObject(i)?.optString("retryDelay").orEmpty()
                        val secs = rd.removeSuffix("s").toDoubleOrNull()
                        if (secs != null) { retry = ceil(secs).toInt(); break }
                    }
                }
            } catch (e: JSONException) {
                // body was not JSON (proxy/HTML error page); keep what we have
            }
            val daily = body.contains("PerDay", ignoreCase = true) || body.contains("per day", ignoreCase = true)
            return ErrorInfo(message, retry, daily)
        }

        /** Milliseconds to wait before retrying [e], or null if it must not be retried. */
        fun retryDelayMs(e: ChatException, attempt: Int, random: Random = Random.Default): Long? {
            if (attempt >= MAX_RETRIES || e.quotaExhausted) return null
            if (e.error != ChatError.RATE_LIMITED && e.error != ChatError.OVERLOADED && e.error != ChatError.SERVER) return null
            val wait = e.retryAfterSec?.let { it * 1000L } ?: ((1000L shl attempt) + random.nextLong(0, 400))
            return if (wait > MAX_AUTO_WAIT_MS) null else wait
        }

        /** The list endpoint returns "models/gemini-x"; generate URLs want the bare id. */
        fun normalizeModelId(id: String) = id.trim().removePrefix("models/")

        fun buildBody(r: ChatRequest): String {
            val contents = JSONArray()
            r.history.forEach {
                contents.put(
                    JSONObject()
                        .put("role", if (it.role == Role.USER) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
                )
            }
            val parts = JSONArray()
            if (r.image != null) {
                parts.put(
                    JSONObject().put(
                        "inlineData",
                        JSONObject()
                            .put("mimeType", "image/jpeg")
                            .put("data", Base64.getEncoder().encodeToString(r.image))
                    )
                )
            }
            parts.put(JSONObject().put("text", r.userText))
            contents.put(JSONObject().put("role", "user").put("parts", parts))

            val root = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", r.system))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", MAX_OUTPUT_TOKENS))
            if (r.webSearch) {
                root.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            }
            return root.toString()
        }

        /** Text of one SSE chunk (same shape as a normal response, but partial). Empty if it has no text. */
        fun parseStreamChunk(json: String): String {
            if (json.isEmpty() || json == "[DONE]") return ""
            val parts = try {
                JSONObject(json).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            } catch (e: JSONException) { null } ?: return ""
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (p.optBoolean("thought", false)) continue
                sb.append(p.optString("text"))
            }
            return sb.toString()
        }

        fun parseResponse(json: String): String {
            val candidates = try {
                JSONObject(json).optJSONArray("candidates")
            } catch (e: JSONException) {
                throw ChatException(ChatError.BAD_RESPONSE, e)
            }
            val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw ChatException(ChatError.BAD_RESPONSE)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (p.optBoolean("thought", false)) continue // skip thinking summaries
                sb.append(p.optString("text"))
            }
            val out = sb.toString().trim()
            if (out.isEmpty()) throw ChatException(ChatError.BAD_RESPONSE)
            return out
        }

        /** Keeps models that can generate text via generateContent; drops audio/image/embedding-only ones. */
        fun parseModels(json: String): List<ModelInfo> {
            val arr: JSONArray? = try {
                JSONObject(json).optJSONArray("models")
            } catch (e: JSONException) {
                throw ChatException(ChatError.BAD_RESPONSE, e)
            }
            if (arr == null) return emptyList()
            val skip = listOf("tts", "image", "embedding", "audio", "live", "robotics", "computer-use", "aqa", "imagen", "veo")
            val out = mutableListOf<ModelInfo>()
            for (i in 0 until arr.length()) {
                val m = arr.optJSONObject(i) ?: continue
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                val canGenerate = (0 until methods.length()).any { methods.optString(it) == "generateContent" }
                val id = normalizeModelId(m.optString("name"))
                if (!canGenerate || id.isEmpty() || skip.any { id.contains(it) }) continue
                out += ModelInfo(id, m.optString("displayName").ifBlank { id })
            }
            return out
        }

        fun mapStatus(code: Int, body: String = ""): ChatError {
            // Google reports a bad key as HTTP 400 with reason API_KEY_INVALID, not 401.
            if (code == 400 && (body.contains("API_KEY_INVALID") || body.contains("API key not valid"))) {
                return ChatError.UNAUTHORIZED
            }
            return when (code) {
                400, 404, 413, 422 -> ChatError.BAD_REQUEST
                401, 403 -> ChatError.UNAUTHORIZED
                429 -> ChatError.RATE_LIMITED
                503 -> ChatError.OVERLOADED
                504 -> ChatError.TIMEOUT
                in 500..599 -> ChatError.SERVER
                else -> ChatError.UNKNOWN
            }
        }
    }
}
