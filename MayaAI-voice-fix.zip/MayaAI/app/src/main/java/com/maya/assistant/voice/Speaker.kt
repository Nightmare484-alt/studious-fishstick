package com.maya.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private val SilentLevel: StateFlow<Float> = MutableStateFlow(0f)

interface Speaker {
    /** 0..1 mouth-opening level of the voice currently playing (0 when silent or unknown). Drives lip sync. */
    val level: StateFlow<Float> get() = SilentLevel

    /** Speaks [text]; [onDone] is called when finished, stopped, or if speech is unavailable. */
    fun speak(text: String, onDone: () -> Unit)
    fun stop()
    fun release()

    /**
     * Streaming speech: call [beginStream], then [feed] each sentence the moment it is available, then [endStream].
     * [onDone] fires after the last fed sentence has been spoken. Default = buffer and speak once at the end.
     */
    fun beginStream(onDone: () -> Unit) { streamBuf.clear(); streamDone = onDone }
    fun feed(sentence: String) { streamBuf.append(sentence).append(' ') }
    fun endStream() { val t = streamBuf.toString().trim(); streamBuf.clear(); speak(t, streamDone) }
}

private val streamBuf = StringBuilder()
private var streamDone: () -> Unit = {}

/**
 * Cuts streamed text into speakable sentences as it arrives. The first piece is released early (at a clause
 * boundary after [MIN_FIRST] chars) so speech starts as soon as possible.
 */
class SentenceSplitter {
    private val buf = StringBuilder()
    private var first = true

    fun push(delta: String): List<String> {
        buf.append(delta)
        val out = mutableListOf<String>()
        while (true) {
            val cut = findCut() ?: break
            val piece = stripMarkdown(buf.substring(0, cut))
            buf.delete(0, cut)
            if (piece.isNotBlank()) { out += piece; first = false }
        }
        return out
    }

    fun flush(): List<String> {
        val piece = stripMarkdown(buf.toString()); buf.clear()
        return if (piece.isBlank()) emptyList() else listOf(piece)
    }

    private fun findCut(): Int? {
        for (i in buf.indices) {
            val c = buf[i]
            val boundary = c == '.' || c == '!' || c == '?' || c == '\n' || (first && (c == ',' || c == ';' || c == ':') && i >= MIN_FIRST)
            if (!boundary || i + 1 >= buf.length) continue // wait for the next char: avoids "3.5" / "e.g." splits at the very end
            val next = buf[i + 1]
            if ((c == '.' || c == ',') && next.isDigit()) continue
            if (next.isWhitespace() || c == '\n') return i + 1
        }
        return null
    }

    companion object { const val MIN_FIRST = 12 }
}

/** Removes markdown noise so replies sound natural when read aloud. */
fun stripMarkdown(text: String): String = text
    .replace(Regex("```[\\s\\S]*?```"), " code block omitted. ")
    .replace(Regex("[*_`#>~]+"), "")
    .replace(Regex("\\[(.*?)]\\((.*?)\\)"), "$1")
    .replace(Regex("\\s+"), " ")
    .trim()

class AndroidSpeaker(context: Context) : Speaker {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var failed = false
    private var pending: Pair<String, () -> Unit>? = null
    private var currentDone: (() -> Unit)? = null
    private val _level = MutableStateFlow(0f)
    override val level: StateFlow<Float> = _level.asStateFlow()
    private val closeMouth = Runnable { _level.value = 0f }

    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        main.post {
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                pickBestVoice()
                pending?.let { (t, d) -> speakNow(t, d) }
            } else {
                failed = true
                pending?.second?.invoke()
            }
            pending = null
        }
    }

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            // Word boundaries (not every engine sends them): open the mouth per word, close it between words.
            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                _level.value = ((end - start) / 6f).coerceIn(0.45f, 1f)
                main.removeCallbacks(closeMouth)
                main.postDelayed(closeMouth, 170)
            }
            override fun onDone(utteranceId: String?) { finish() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finish() }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { finish() }
        })
    }

    /** Prefer the highest-quality installed voice in the device language (default is often the worst). */
    private fun pickBestVoice() {
        try {
            val lang = java.util.Locale.getDefault().language
            tts.voices?.filter { it.locale.language == lang && !it.features.contains("notInstalled") }
                ?.maxByOrNull { it.quality }?.let { tts.voice = it }
            tts.setSpeechRate(0.96f)
        } catch (_: Exception) {}
    }

    private fun finish() {
        main.post {
            main.removeCallbacks(closeMouth)
            _level.value = 0f
            val d = currentDone
            currentDone = null
            d?.invoke()
        }
    }

    override fun speak(text: String, onDone: () -> Unit) {
        when {
            failed || text.isBlank() -> onDone()
            !ready -> pending = text to onDone
            else -> speakNow(text, onDone)
        }
    }

    private fun speakNow(text: String, onDone: () -> Unit) {
        currentDone = onDone
        // TTS limits a single utterance to ~4000 chars.
        val result = tts.speak(text.take(TextToSpeech.getMaxSpeechInputLength() - 1), TextToSpeech.QUEUE_FLUSH, null, "maya")
        if (result != TextToSpeech.SUCCESS) finish()
    }

    override fun stop() {
        pending = null
        main.removeCallbacks(closeMouth)
        _level.value = 0f
        if (ready) tts.stop()
    }

    override fun release() {
        tts.stop()
        tts.shutdown()
    }
}
