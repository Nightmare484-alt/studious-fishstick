package com.maya.assistant.vm

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.maya.assistant.actions.ActionExecutor
import com.maya.assistant.actions.ActionResult
import com.maya.assistant.actions.AndroidActionExecutor
import com.maya.assistant.actions.CommandRouter
import com.maya.assistant.actions.LocalCommand
import com.maya.assistant.ai.GeminiClient
import com.maya.assistant.ai.ChatClient
import com.maya.assistant.ai.ChatError
import com.maya.assistant.ai.ChatException
import com.maya.assistant.ai.ChatRequest
import com.maya.assistant.ai.SystemPrompt
import com.maya.assistant.capture.CaptureBus
import com.maya.assistant.capture.CaptureFailure
import com.maya.assistant.capture.CaptureResult
import com.maya.assistant.data.ApiKeyStore
import com.maya.assistant.data.ChatMessage
import com.maya.assistant.data.FileMemoryStore
import com.maya.assistant.data.KeystoreApiKeyStore
import com.maya.assistant.data.MayaSettings
import com.maya.assistant.data.MemoryStore
import com.maya.assistant.data.PrefsSettingsStore
import com.maya.assistant.data.Role
import com.maya.assistant.data.SettingsStore
import com.maya.assistant.voice.AndroidSpeaker
import com.maya.assistant.voice.GeminiSpeaker
import com.maya.assistant.voice.AndroidSpeechInput
import com.maya.assistant.voice.Speaker
import com.maya.assistant.voice.SpeechError
import com.maya.assistant.voice.SpeechInput
import com.maya.assistant.voice.SpeechListener
import com.maya.assistant.voice.SentenceSplitter
import com.maya.assistant.voice.stripMarkdown
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

class MayaViewModel(
    private val chat: ChatClient,
    private val keys: ApiKeyStore,
    private val settingsStore: SettingsStore,
    private val memory: MemoryStore,
    private val speech: SpeechInput,
    private val speaker: Speaker,
    private val actions: ActionExecutor,
    captures: Flow<CaptureResult> = CaptureBus.results,
) : ViewModel() {

    private val _state = MutableStateFlow(
        UiState(settings = settingsStore.settings, notes = memory.all(), hasApiKey = keys.get().isNotBlank())
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val history = mutableListOf<ChatMessage>()
    private var job: Job? = null
    private var pendingScreenPrompt = SCREEN_PROMPT
    private var lastText: String? = null
    private var lastAt = 0L
    private var blockedUntil = 0L // set after a real rate limit so we stop sending requests that cannot succeed

    /** Live 0..1 mouth-opening level while Maya's voice plays; drives the avatar lip sync. */
    val mouthLevel: StateFlow<Float> get() = speaker.level

    /** True while the app UI is not visible but work (thinking/speaking) continues. */
    fun setAppForeground(foreground: Boolean) = _state.update { it.copy(inForeground = foreground) }

    val micPermissionAsked: Boolean get() = settingsStore.micPermissionAsked

    init {
        viewModelScope.launch {
            captures.collect { result ->
                when (result) {
                    is CaptureResult.Success -> run(pendingScreenPrompt, result.jpeg)
                    is CaptureResult.Failure -> fail(
                        if (result.reason == CaptureFailure.DENIED) UiError.CAPTURE_DENIED else UiError.CAPTURE_FAILED
                    )
                }
            }
        }
    }

    // ---- voice -------------------------------------------------------------------------------

    /** Call only after the microphone permission has been granted. */
    fun startListening() {
        when (_state.value.phase) {
            Phase.LISTENING -> { speech.stop(); return }
            Phase.SPEAKING -> speaker.stop()
            Phase.THINKING -> job?.cancel()
            else -> Unit
        }
        if (!speech.available) return fail(UiError.SPEECH_UNAVAILABLE)
        _state.update { it.copy(phase = Phase.LISTENING, partial = "", error = null, errorDetail = null, status = null) }
        speech.start(object : SpeechListener {
            override fun onPartial(text: String) {
                _state.update { it.copy(partial = text) }
            }
            override fun onResult(text: String) {
                submitText(text)
            }
            override fun onError(error: SpeechError) {
                fail(
                    when (error) {
                        SpeechError.NO_MATCH, SpeechError.TIMEOUT -> UiError.SPEECH_NO_MATCH
                        SpeechError.NETWORK -> UiError.SPEECH_NETWORK
                        SpeechError.BUSY -> UiError.SPEECH_BUSY
                        SpeechError.PERMISSION -> UiError.MIC_DENIED
                        SpeechError.UNAVAILABLE -> UiError.SPEECH_UNAVAILABLE
                        SpeechError.OTHER -> UiError.SPEECH_OTHER
                    }
                )
            }
        })
    }

    fun stopSpeaking() {
        speaker.stop()
        _state.update { if (it.phase == Phase.SPEAKING) it.copy(phase = Phase.IDLE) else it }
    }

    fun markMicAsked() {
        settingsStore.micPermissionAsked = true
    }

    fun micPermissionDenied(blocked: Boolean) = fail(if (blocked) UiError.MIC_BLOCKED else UiError.MIC_DENIED)

    // ---- requests ----------------------------------------------------------------------------

    fun submitText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        run(clean, null)
    }

    fun submitImage(jpeg: ByteArray, prompt: String = PHOTO_PROMPT) = run(prompt, jpeg)

    fun submitFile(name: String, content: String) {
        if (content.isBlank()) return fail(UiError.FILE_FAILED)
        run("$FILE_PROMPT\n\nFile name: $name\n---\n$content", null)
    }

    fun screenCaptureStarting(prompt: String = SCREEN_PROMPT) {
        pendingScreenPrompt = prompt
        _state.update {
            it.copy(
                phase = Phase.IDLE, error = null,
                status = "Switch to the screen you want me to see. Taking one screenshot in a few seconds…",
            )
        }
    }

    fun launchableApps() = actions.launchableApps()

    fun launchApp(packageName: String) {
        if (!actions.launch(packageName)) fail(UiError.APP_FAILED)
    }

    fun screenCaptureDenied() = fail(UiError.CAPTURE_DENIED)
    fun reportError(error: UiError) = fail(error)

    fun dismissError() = _state.update { it.copy(error = null, errorDetail = null, phase = if (it.phase == Phase.ERROR) Phase.IDLE else it.phase) }

    private fun run(text: String, image: ByteArray?) {
        val now = System.currentTimeMillis()
        // One user action = one request: drop an identical text submitted again while it is still being processed.
        if (image == null && _state.value.phase == Phase.THINKING && text == lastText && now - lastAt < DUPLICATE_WINDOW_MS) return
        lastText = if (image == null) text else null
        lastAt = now
        job?.cancel()
        speaker.stop()
        _state.update { it.copy(phase = Phase.THINKING, partial = "", error = null, errorDetail = null, status = null) }
        job = viewModelScope.launch {
            if (image == null) {
                val command = CommandRouter.route(text)
                if (command != null) {
                    val local = handleLocal(command)
                    if (local != null) {
                        deliver(local)
                        return@launch
                    }
                }
            }
            val key = keys.get()
            if (key.isBlank()) {
                _state.update { it.copy(hasApiKey = false) }
                return@launch fail(UiError.MISSING_KEY)
            }
            val waitMs = blockedUntil - System.currentTimeMillis()
            if (waitMs > 0) {
                // Do not hammer a provider that just said "slow down"; tell the truth instead.
                return@launch fail(UiError.RATE_LIMITED, "Google asked us to wait. Try again in ${(waitMs + 999) / 1000}s.")
            }
            try {
                val s = settingsStore.settings
                // Stream the reply: text appears and the first sentence is voiced as soon as it arrives,
                // instead of waiting for the whole answer before anything is shown or spoken.
                val speak = s.speakReplies
                val splitter = SentenceSplitter()
                val acc = StringBuilder()
                if (speak) speaker.beginStream {
                    _state.update { if (it.phase == Phase.SPEAKING) it.copy(phase = Phase.IDLE) else it }
                }
                val reply = try {
                    chat.sendStreaming(
                        ChatRequest(
                            system = SystemPrompt.build(s.userName, memory.all()),
                            history = history.toList(),
                            userText = text,
                            image = image,
                            model = s.model,
                            apiKey = key,
                            webSearch = s.webSearch,
                        )
                    ) { delta ->
                        acc.append(delta)
                        val shown = acc.toString()
                        _state.update { it.copy(reply = shown, phase = if (speak) Phase.SPEAKING else Phase.IDLE, error = null, errorDetail = null) }
                        if (speak) splitter.push(delta).forEach { speaker.feed(it) }
                    }
                } catch (e: Exception) {
                    if (speak) speaker.stop() // drop any half-spoken stream on failure/cancel
                    throw e
                }
                if (speak) {
                    splitter.flush().forEach { speaker.feed(it) }
                    speaker.endStream()
                }
                _state.update { it.copy(reply = reply, phase = if (speak) Phase.SPEAKING else Phase.IDLE) }
                history += ChatMessage(Role.USER, if (image != null) "[shared an image] $text" else text)
                history += ChatMessage(Role.ASSISTANT, reply.take(MAX_HISTORY_CHARS))
                while (history.size > MAX_HISTORY) history.removeAt(0)
            } catch (e: CancellationException) {
                throw e
            } catch (e: ChatException) {
                if (e.error == ChatError.UNAUTHORIZED) _state.update { it.copy(hasApiKey = false) }
                if (e.error == ChatError.RATE_LIMITED) {
                    blockedUntil = System.currentTimeMillis() +
                        if (e.quotaExhausted) DAILY_BLOCK_MS else (e.retryAfterSec ?: DEFAULT_BLOCK_S) * 1000L
                }
                fail(e.error.toUi(), describe(e, settingsStore.settings.model))
            } catch (e: Exception) {
                fail(UiError.UNKNOWN)
            }
        }
    }

    /** Turns a provider failure into a specific sentence (which limit, how long) instead of one generic message. */
    private fun describe(e: ChatException, model: String): String? = when {
        e.error == ChatError.RATE_LIMITED && e.quotaExhausted ->
            "The daily free quota for $model is used up. Pick another model in Settings or try tomorrow."
        e.error == ChatError.RATE_LIMITED ->
            "Google asked to wait ${e.retryAfterSec ?: DEFAULT_BLOCK_S}s before the next request to $model."
        e.error == ChatError.BAD_REQUEST || e.error == ChatError.SERVER || e.error == ChatError.OVERLOADED ||
            e.error == ChatError.UNAUTHORIZED -> e.detail
        else -> null
    }

    /** Returns the reply text if handled locally, or null to fall back to the AI. */
    private fun handleLocal(command: LocalCommand): String? = when (command) {
        is LocalCommand.Remember -> {
            val note = memory.add(command.fact)
            _state.update { it.copy(notes = memory.all()) }
            if (note != null) "Okay, I'll remember that: ${note.text}" else null
        }
        else -> when (val r = actions.execute(command)) {
            is ActionResult.Done -> r.message
            is ActionResult.Failed -> r.message
            ActionResult.NotHandled -> null
        }
    }

    private fun deliver(reply: String) {
        val speak = settingsStore.settings.speakReplies
        _state.update { it.copy(reply = reply, phase = if (speak) Phase.SPEAKING else Phase.IDLE, error = null, errorDetail = null) }
        if (speak) {
            speaker.speak(stripMarkdown(reply)) {
                _state.update { if (it.phase == Phase.SPEAKING) it.copy(phase = Phase.IDLE) else it }
            }
        }
    }

    private fun fail(error: UiError, detail: String? = null) {
        _state.update { it.copy(phase = Phase.ERROR, error = error, errorDetail = detail, partial = "", status = null) }
    }

    private fun ChatError.toUi(): UiError = when (this) {
        ChatError.MISSING_KEY -> UiError.MISSING_KEY
        ChatError.UNAUTHORIZED -> UiError.UNAUTHORIZED
        ChatError.RATE_LIMITED -> UiError.RATE_LIMITED
        ChatError.OVERLOADED -> UiError.OVERLOADED
        ChatError.BAD_REQUEST -> UiError.BAD_REQUEST
        ChatError.SERVER -> UiError.SERVER
        ChatError.NETWORK -> UiError.NETWORK
        ChatError.TIMEOUT -> UiError.TIMEOUT
        ChatError.BAD_RESPONSE -> UiError.BAD_RESPONSE
        ChatError.UNKNOWN -> UiError.UNKNOWN
    }

    // ---- settings / memory ---------------------------------------------------------------------

    fun updateSettings(transform: (MayaSettings) -> MayaSettings) {
        val next = transform(settingsStore.settings)
        val modelChanged = next.model != settingsStore.settings.model
        settingsStore.settings = next
        _state.update { it.copy(settings = next, modelCheck = if (modelChanged) Check() else it.modelCheck) }
    }

    fun saveApiKey(key: String) {
        keys.set(key)
        _state.update {
            it.copy(hasApiKey = keys.get().isNotBlank(), error = null, phase = Phase.IDLE,
                connection = Check(), modelCheck = Check(), models = emptyList())
        }
        if (keys.get().isNotBlank()) refreshModels() // real auth check; a saved key alone proves nothing
    }

    fun clearApiKey() {
        keys.clear()
        _state.update { it.copy(hasApiKey = false, connection = Check(), modelCheck = Check(), models = emptyList()) }
    }

    /** Fetches the model list from Google; success also proves the key works. */
    fun refreshModels() {
        val key = keys.get()
        if (key.isBlank()) {
            _state.update { it.copy(connection = Check(error = UiError.MISSING_KEY)) }
            return
        }
        _state.update { it.copy(connection = Check(running = true)) }
        viewModelScope.launch {
            try {
                val models = chat.listModels(key)
                _state.update {
                    it.copy(models = models, hasApiKey = true,
                        connection = Check(ok = "Connected. ${models.size} chat models available."))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ChatException) {
                _state.update {
                    it.copy(connection = Check(error = e.error.toUi()),
                        hasApiKey = if (e.error == ChatError.UNAUTHORIZED) false else it.hasApiKey)
                }
            } catch (e: Exception) {
                _state.update { it.copy(connection = Check(error = UiError.UNKNOWN)) }
            }
        }
    }

    /** Sends one tiny request to the selected model. Never swaps the model. */
    fun testSelectedModel() {
        val key = keys.get()
        if (key.isBlank()) {
            _state.update { it.copy(modelCheck = Check(error = UiError.MISSING_KEY)) }
            return
        }
        val model = settingsStore.settings.model
        _state.update { it.copy(modelCheck = Check(running = true)) }
        viewModelScope.launch {
            try {
                chat.testModel(key, model)
                _state.update { it.copy(modelCheck = Check(ok = "$model replied successfully.")) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ChatException) {
                _state.update { it.copy(modelCheck = Check(error = e.error.toUi())) }
            } catch (e: Exception) {
                _state.update { it.copy(modelCheck = Check(error = UiError.UNKNOWN)) }
            }
        }
    }

    fun addNote(text: String) {
        memory.add(text)
        _state.update { it.copy(notes = memory.all()) }
    }

    fun removeNote(id: Long) {
        memory.remove(id)
        _state.update { it.copy(notes = memory.all()) }
    }

    fun clearNotes() {
        memory.clear()
        _state.update { it.copy(notes = emptyList()) }
    }

    fun newConversation() {
        job?.cancel()
        speaker.stop()
        history.clear()
        _state.update { it.copy(reply = "", partial = "", error = null, status = null, phase = Phase.IDLE) }
    }

    /** Wipes the key, notes, settings and conversation. */
    fun deleteAllData() {
        newConversation()
        keys.clear()
        memory.clear()
        settingsStore.clear()
        _state.value = UiState(settings = settingsStore.settings)
    }

    override fun onCleared() {
        job?.cancel()
        speech.release()
        speaker.release()
    }

    companion object {
        const val MAX_HISTORY = 12
        const val MAX_HISTORY_CHARS = 1500
        const val DUPLICATE_WINDOW_MS = 3_000L
        const val DEFAULT_BLOCK_S = 20
        const val DAILY_BLOCK_MS = 5 * 60_000L
        const val SCREEN_PROMPT = "This is a screenshot of my screen. Tell me what's on it and point out anything I should act on."
        const val PHOTO_PROMPT = "What do you see? Describe it and mention anything useful I should know."
        const val FILE_PROMPT = "Summarize this file and point out anything important."

        fun factory(context: Context): ViewModelProvider.Factory {
            val app = context.applicationContext
            val apiKeys = KeystoreApiKeyStore(app)
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T = MayaViewModel(
                    chat = GeminiClient(),
                    keys = apiKeys,
                    settingsStore = PrefsSettingsStore(app),
                    memory = FileMemoryStore(File(app.filesDir, "memory.json")),
                    speech = AndroidSpeechInput(app),
                    speaker = GeminiSpeaker(apiKeys, AndroidSpeaker(app)),
                    actions = AndroidActionExecutor(app),
                ) as T
            }
        }
    }
}
