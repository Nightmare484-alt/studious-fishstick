package com.maya.assistant.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.maya.assistant.R
import com.maya.assistant.vm.Phase
import com.maya.assistant.vm.UiError
import com.maya.assistant.vm.UiState
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.PI
import kotlin.math.sin

/** While speaking, the face alternates closed/open with the real audio level (lip sync on the face image). */
private fun faceFor(phase: Phase, mouthOpen: Boolean): Int = when (phase) {
    Phase.IDLE -> R.drawable.maya_happy
    Phase.LISTENING -> R.drawable.maya_serious
    Phase.THINKING -> R.drawable.maya_thinking
    Phase.SPEAKING -> if (mouthOpen) R.drawable.maya_talking else R.drawable.maya_happy
    Phase.ERROR -> R.drawable.maya_serious
}

/** Height of the title area; the avatar is laid out below it so her face is never covered. */
private val HeaderHeight = 150.dp

@Composable
fun HomeScreen(
    state: UiState,
    onMic: () -> Unit,
    onCamera: () -> Unit,
    onScreen: () -> Unit,
    onApps: () -> Unit,
    onSettings: () -> Unit,
    onProfile: () -> Unit,
    onSendText: (String) -> Unit,
    onDismissError: () -> Unit,
    onAppSettings: () -> Unit,
    mouthLevel: StateFlow<Float>? = null,
) {
    var typing by rememberSaveable { mutableStateOf(false) }
    val mouth = mouthLevel?.collectAsState()
    // Only recomposes when the mouth flips open/closed, not on every audio sample.
    val mouthOpen by remember(state.phase) {
        derivedStateOf { state.phase == Phase.SPEAKING && (mouth?.value ?: 0f) > 0.3f }
    }

    Box(Modifier.fillMaxSize().background(Navy)) {
        // Avatar: scaled to the screen WIDTH (no side cropping, no stretching), placed below the title area.
        Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = HeaderHeight)) {
            MayaAvatar(phase = state.phase, mouth = mouth, modifier = Modifier.fillMaxSize())
            // Soften the seam between the navy header area and the render's own background.
            Box(
                Modifier.fillMaxWidth().height(72.dp)
                    .background(Brush.verticalGradient(listOf(Navy, Color.Transparent)))
            )
        }
        // Tint the grey-blue render toward the app's navy and fade the bottom for legibility of the controls.
        Box(Modifier.fillMaxSize().background(Navy.copy(alpha = 0.40f)))
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.62f to Color.Transparent,
                    0.82f to Navy.copy(alpha = 0.70f),
                    1f to Navy,
                )
            )
        )

        // Ambient blue/purple glow from the top corners and a soft violet bloom low behind the controls.
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    colors = listOf(MayaPurple.copy(alpha = 0.22f), Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(0f, 0f), radius = 900f,
                )
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    colors = listOf(MayaBlue.copy(alpha = 0.18f), Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(Float.POSITIVE_INFINITY, 0f), radius = 900f,
                )
            )
        )

        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            TopBar(onProfile = onProfile, onSettings = onSettings)
            Spacer(Modifier.weight(1f))
            ReplyBubble(
                state = state,
                mouthOpen = mouthOpen,
                onKeyboard = { typing = !typing },
                onDismissError = onDismissError,
                onSettings = onSettings,
                onAppSettings = onAppSettings,
            )
            if (typing) {
                TypeRow(onSend = { text ->
                    onSendText(text)
                    typing = false
                })
            }
            Spacer(Modifier.size(14.dp))
            ControlRow(phase = state.phase, onMic = onMic, onCamera = onCamera, onScreen = onScreen, onApps = onApps, onSettings = onSettings)
            Spacer(Modifier.size(10.dp))
        }
    }
}

/**
 * The Maya render with state-driven motion. It is a single still image, so motion is whole-body transforms
 * (breathing, sway, lean, tilt, an audio-driven bob while speaking, a short greeting settle on launch). There is
 * no eye/mouth/hand layer in the assets, so blinking, hand waves and mouth movement on the full-body image are
 * not possible; lip sync is shown on the face image in the reply card instead.
 */
@Composable
private fun MayaAvatar(phase: Phase, mouth: State<Float>?, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "avatar")
    val breath = t.animateFloat(0f, 1f, infiniteRepeatable(tween(3800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breath")
    val sway = t.animateFloat(-1f, 1f, infiniteRepeatable(tween(6400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "sway")
    val greet = remember { Animatable(0f) }
    LaunchedEffect(Unit) { greet.animateTo(1f, tween(1600, easing = FastOutSlowInEasing)) }
    // Smoothly blend between per-state poses so changing state never snaps.
    val lean by animateFloatAsState(if (phase == Phase.LISTENING) 1f else 0f, tween(500), label = "lean")
    val think by animateFloatAsState(if (phase == Phase.THINKING) 1f else 0f, tween(600), label = "think")

    Image(
        painter = painterResource(R.drawable.maya_hero),
        contentDescription = "Maya",
        modifier = modifier.graphicsLayer {
            transformOrigin = TransformOrigin(0.5f, 0.95f) // pivot near the hips so the head moves most
            val speak = if (phase == Phase.SPEAKING) (mouth?.value ?: 0f) else 0f
            val g = greet.value
            val settle = 1f - g
            scaleX = 1f + 0.004f * breath.value + 0.012f * lean + 0.03f * settle
            scaleY = scaleX
            rotationZ = 0.35f * sway.value + 0.9f * think + 0.6f * lean +
                1.4f * sin(g * 3f * PI.toFloat()) * settle
            translationX = -5.dp.toPx() * think
            translationY = -2.dp.toPx() * breath.value - 3.dp.toPx() * speak
        },
        contentScale = ContentScale.Crop,
        alignment = Alignment.TopCenter,
    )
}

@Composable
private fun TopBar(onProfile: () -> Unit, onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Top,
    ) {
        RoundButton(onClick = onProfile, description = "Memory", size = 44.dp) {
            Icon(Icons.Default.Person, contentDescription = null, tint = Color.White)
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.ic_logo_m), contentDescription = null, modifier = Modifier.size(56.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Maya AI", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White, letterSpacing = 0.5.sp)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Default.CheckCircle, contentDescription = "Verified", tint = MayaCyan, modifier = Modifier.size(22.dp))
            }
            Text(
                "Your Personal Assistant\nAlways With You \uD83D\uDC99",
                fontSize = 14.sp, color = TextSecondary, textAlign = TextAlign.Center,
            )
        }
        RoundButton(onClick = onSettings, description = "Settings", size = 44.dp) {
            Icon(Icons.Default.Settings, contentDescription = null, tint = Color.White)
        }
    }
}

@Composable
private fun ReplyBubble(
    state: UiState,
    mouthOpen: Boolean,
    onKeyboard: () -> Unit,
    onDismissError: () -> Unit,
    onSettings: () -> Unit,
    onAppSettings: () -> Unit,
) {
    val error = state.error
    val name = state.settings.userName.trim()
    val title: String?
    val body: String
    when {
        error != null -> { title = null; body = error.message() }
        state.status != null -> { title = null; body = state.status }
        state.phase == Phase.LISTENING -> { title = null; body = state.partial.ifBlank { "Listening…" } }
        state.phase == Phase.THINKING -> { title = null; body = "Thinking…" }
        state.reply.isNotBlank() -> { title = null; body = state.reply }
        else -> {
            title = if (name.isEmpty()) "Hello!" else "Hello $name!"
            body = "I'm Maya, your AI assistant.\nHow can I help you today?"
        }
    }

    Surface(
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().heightIn(max = 240.dp),
        shape = RoundedCornerShape(22.dp),
        color = CardBg,
        border = BorderStroke(1.2.dp, Brush.linearGradient(listOf(MayaCyan.copy(alpha = 0.8f), MayaBlue, MayaViolet.copy(alpha = 0.9f)))),
        shadowElevation = 12.dp,
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Image(
                painter = painterResource(faceFor(state.phase, mouthOpen)),
                contentDescription = "Maya, ${state.phase.name.lowercase()}",
                modifier = Modifier.size(48.dp).clip(CircleShape).border(1.8.dp, MayaRingGradient, CircleShape),
                contentScale = ContentScale.Crop,
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                if (title != null) Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                Text(
                    body,
                    fontSize = 15.sp,
                    color = if (error != null) Color(0xFFFFA3B1) else Color.White,
                )
                if (error != null && !state.errorDetail.isNullOrBlank()) {
                    Text(state.errorDetail, fontSize = 13.sp, color = Color(0xFFFFA3B1).copy(alpha = 0.85f))
                }
                if (error != null) {
                    Row {
                        when (error) {
                            UiError.MISSING_KEY, UiError.UNAUTHORIZED, UiError.BAD_REQUEST ->
                                TextButton(onClick = onSettings) { Text("Open Settings", color = MayaCyan, fontWeight = FontWeight.SemiBold) }
                            UiError.MIC_BLOCKED -> TextButton(onClick = onAppSettings) { Text("App settings", color = MayaCyan, fontWeight = FontWeight.SemiBold) }
                            else -> Unit
                        }
                        TextButton(onClick = onDismissError) { Text("Dismiss", color = TextSecondary) }
                    }
                }
            }
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(NavyLift)
                    .border(1.dp, MayaBlueSoft.copy(alpha = 0.7f), CircleShape).clickable(onClick = onKeyboard)
                    .semantics { contentDescription = "Type instead" },
                contentAlignment = Alignment.Center,
            ) {
                Icon(painterResource(R.drawable.ic_keyboard), contentDescription = null, tint = MayaCyan)
            }
        }
    }
}

@Composable
private fun TypeRow(onSend: (String) -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    fun send() {
        if (text.isNotBlank()) {
            onSend(text)
            text = ""
        }
    }
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Type to Maya") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { send() }),
            maxLines = 3,
            shape = RoundedCornerShape(20.dp),
            colors = mayaFieldColors(),
        )
        Spacer(Modifier.width(8.dp))
        RoundButton(onClick = { send() }, description = "Send", size = 48.dp) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color.White)
        }
    }
}

@Composable
private fun ControlRow(
    phase: Phase,
    onMic: () -> Unit,
    onCamera: () -> Unit,
    onScreen: () -> Unit,
    onApps: () -> Unit,
    onSettings: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom,
    ) {
        LabeledButton("Camera", onCamera) { Icon(painterResource(R.drawable.ic_camera), null, tint = Color.White) }
        LabeledButton("Screen", onScreen) { Icon(painterResource(R.drawable.ic_screen), null, tint = Color.White) }
        MicButton(phase, onMic)
        LabeledButton("Apps", onApps) { Icon(painterResource(R.drawable.ic_apps), null, tint = Color.White) }
        LabeledButton("Settings", onSettings) { Icon(Icons.Default.Settings, null, tint = Color.White) }
    }
}

@Composable
private fun LabeledButton(label: String, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(64.dp)) {
        RoundButton(onClick = onClick, description = label, size = 54.dp, content = icon)
        Spacer(Modifier.size(4.dp))
        Text(label, fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun MicButton(phase: Phase, onClick: () -> Unit) {
    val listening = phase == Phase.LISTENING
    // The pulse only runs while listening; an always-on infinite transition recomposes every frame for nothing.
    val factor = if (listening) {
        rememberInfiniteTransition(label = "pulse").animateFloat(
            initialValue = 1f,
            targetValue = 1.10f,
            animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
            label = "pulseScale",
        ).value
    } else 1f
    val label = when (phase) {
        Phase.LISTENING -> "Listening… tap to send"
        Phase.THINKING -> "Thinking…"
        Phase.SPEAKING -> "Tap to stop"
        else -> "Tap to Talk"
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(120.dp)) {
        Box(
            Modifier
                .size(88.dp)
                .scale(if (listening) factor else 1f)
                .shadow(if (listening) 22.dp else 14.dp, CircleShape, ambientColor = MayaViolet, spotColor = MayaBlue)
                .clip(CircleShape)
                .background(MayaRingGradient)
                .padding(3.5.dp)
                .clip(CircleShape)
                .background(Brush.verticalGradient(listOf(NavyLift, Navy)))
                .clickable(onClick = onClick)
                .semantics { contentDescription = label },
            contentAlignment = Alignment.Center,
        ) {
            val icon = if (phase == Phase.SPEAKING) R.drawable.ic_stop else R.drawable.ic_mic
            Icon(painterResource(icon), contentDescription = null, tint = Color.White, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.size(4.dp))
        Text(label, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
    }
}

@Composable
fun RoundButton(onClick: () -> Unit, description: String, size: Dp, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(size)
            .shadow(8.dp, CircleShape, ambientColor = MayaPurple, spotColor = MayaBlue)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(NavyLift, NavyMid)))
            .border(1.2.dp, Brush.linearGradient(listOf(MayaCyan, MayaBlue, MayaViolet)), CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { content() }
}
