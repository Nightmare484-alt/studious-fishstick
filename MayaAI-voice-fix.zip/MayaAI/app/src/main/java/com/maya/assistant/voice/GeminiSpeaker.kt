package com.maya.assistant.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import com.maya.assistant.data.ApiKeyStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.Base64
import kotlin.math.sqrt

/**
 * Natural voice via Gemini TTS using the *streaming* endpoint: audio starts playing as soon as the first PCM chunk
 * arrives (not after the whole clip is synthesized), through one continuous AudioTrack. Sentences fed while the
 * text is still being generated are voiced immediately. If Gemini TTS fails, times out (fast, ~6 s) or is rate
 * limited, the remaining text is spoken by the system [fallback] speaker so Maya is never silent or stuck.
 *
 * Quota note: the free tier allows only a few TTS requests per minute, so one reply uses at most two requests:
 * the first sentence (to start speaking at once) and the rest of the reply.
 */
class GeminiSpeaker(
    private val keys: ApiKeyStore,
    private val fallback: Speaker,
    private val model: String = DEFAULT_MODEL,
    private val voice: String = DEFAULT_VOICE,
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta",
) : Speaker {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var session: Session? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var blockedUntil = 0L
    @Volatile private var streamUnsupported = false
    private val _level = MutableStateFlow(0f)
    override val level: StateFlow<Float> = _level.asStateFlow()
    private var levelJob: Job? = null

    /** System voice, with its word-boundary level forwarded so lip sync still works. */
    private fun speakFallback(text: String, onDone: () -> Unit) {
        levelJob?.cancel()
        levelJob = scope.launch { fallback.level.collect { _level.value = it } }
        fallback.speak(text, onDone)
    }

    // ---- Speaker API ---------------------------------------------------------------------------------------

    override fun speak(text: String, onDone: () -> Unit) {
        beginStream(onDone)
        val splitter = SentenceSplitter()
        (splitter.push(text) + splitter.flush()).forEach { feed(it) }
        endStream()
    }

    override fun beginStream(onDone: () -> Unit) {
        stop()
        val s = Session(onDone)
        session = s
        s.start()
    }

    override fun feed(sentence: String) { session?.push(sentence) }

    override fun endStream() { session?.end() }

    override fun stop() {
        session?.cancel()
        session = null
        levelJob?.cancel()
        levelJob = null
        _level.value = 0f
        try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) {}
        fallback.stop()
    }

    override fun release() {
        stop()
        scope.cancel()
        fallback.release()
    }

    // ---- one spoken reply ----------------------------------------------------------------------------------

    private class Item(val text: String, val systemVoice: Boolean)

    private inner class Session(private val onDone: () -> Unit) {
        private val items = Channel<Item>(Channel.UNLIMITED)
        private val pcm = Channel<ByteArray>(Channel.UNLIMITED)
        private val rest = StringBuilder()
        private var firstSent = false
        private var job: Job? = null
        @Volatile private var fallbackText = ""

        fun push(sentence: String) {
            if (sentence.isBlank()) return
            synchronized(rest) {
                if (!firstSent) { firstSent = true; items.trySend(Item(sentence, false)) }
                else rest.append(sentence).append(' ')
            }
        }

        fun end() {
            synchronized(rest) {
                val r = rest.toString().trim()
                if (r.isNotEmpty()) items.trySend(Item(r, r.length > MAX_REST))
                items.close()
            }
        }

        fun cancel() { job?.cancel(); items.close(); pcm.close() }

        fun start() {
            job = scope.launch {
                val key = keys.get()
                val producer = launch { produce(key) }
                try {
                    playAll()
                    producer.join()
                    val tail = fallbackText.trim()
                    if (tail.isNotEmpty() && isActive) {
                        val done = CompletableDeferred<Unit>()
                        withContext(Dispatchers.Main) {
                            speakFallback(tail) { done.complete(Unit) }
                        }
                        done.await()
                    }
                    if (isActive) main.post(onDone)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    main.post(onDone) // never leave the UI stuck in SPEAKING
                }
            }
        }

        /** Synthesizes queued text in order, pushing PCM to the player as it streams in. */
        private suspend fun produce(key: String) {
            val failed = StringBuilder()
            var useSystem = key.isBlank()
            try {
                for (item in items) {
                    for (part in chunk(item.text)) {
                        if (useSystem || item.systemVoice || System.currentTimeMillis() < blockedUntil) {
                            failed.append(part).append(' '); continue
                        }
                        try {
                            synthPart(key, part) { pcm.trySend(it) }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            // Gemini voice failed: if some audio of this part already played, do not repeat it.
                            useSystem = true
                            if (e.hasNoAudio()) failed.append(part).append(' ')
                        }
                    }
                }
            } finally {
                fallbackText = failed.toString()
                pcm.close()
            }
        }

        private var partBytes = 0
        private fun Exception.hasNoAudio() = partBytes == 0

        /** Writes PCM to one continuous streaming AudioTrack; starts playing after a ~120 ms prebuffer. */
        private suspend fun playAll() = withContext(Dispatchers.IO) {
            var t: AudioTrack? = null
            var started = false
            var frames = 0L
            var lvl: Job? = null
            val env = EnvelopeTracker()
            try {
                for (chunk in pcm) {
                    if (t == null) { t = newTrack(); track = t }
                    t.write(chunk, 0, chunk.size)
                    frames += chunk.size / 2
                    env.add(chunk)
                    if (!started && frames >= PREBUFFER_FRAMES) {
                        t.play(); started = true
                        lvl = levelLoop(t, env)
                    }
                }
                if (t != null) {
                    if (!started) { t.play(); started = true; lvl = levelLoop(t, env) }
                    val deadline = System.currentTimeMillis() + frames * 1000L / SAMPLE_RATE + 2_000
                    while (isActive && t.playbackHeadPosition < frames && System.currentTimeMillis() < deadline) delay(30)
                }
            } finally {
                lvl?.cancel()
                _level.value = 0f
                track = null
                if (t != null) {
                    try { t.stop() } catch (_: IllegalStateException) {}
                    t.release()
                }
            }
        }

        private fun CoroutineScope.levelLoop(t: AudioTrack, env: EnvelopeTracker): Job =
            launch {
                while (isActive) {
                    // Mouth follows the loudness of what is actually being played; no extra API calls.
                    _level.value = try { env.at(t.playbackHeadPosition) } catch (_: IllegalStateException) { 0f }
                    delay(40)
                }
            }

        private fun newTrack(): AudioTrack {
            val min = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            return AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(maxOf(min, SAMPLE_RATE)) // ~0.5 s of headroom against underruns
                .build()
        }

        /**
         * Streams one piece of text through Gemini TTS, calling [onPcm] per audio chunk. Returns bytes delivered.
         * Retries once on a fast connection/5xx failure; a slow (timed-out) or rate-limited request goes straight to the
         * fallback voice instead of making the user wait again.
         */
        private fun synthPart(key: String, text: String, onPcm: (ByteArray) -> Unit): Int {
            partBytes = 0
            var attempt = 0
            while (true) {
                try {
                    if (streamUnsupported) {
                        val all = synthOnce(key, text)
                        onPcm(all); partBytes += all.size
                        return partBytes
                    }
                    streamSynth(key, text) { partBytes += it.size; onPcm(it) }
                    if (partBytes == 0) error("no audio")
                    return partBytes
                } catch (e: TtsHttpException) {
                    if (e.code == 429) throw e
                    if (e.code == 400 || e.code == 404) { streamUnsupported = true; continue }
                    if (partBytes > 0 || ++attempt > 1 || e.code < 500) throw e
                } catch (e: SocketTimeoutException) {
                    throw e
                } catch (e: IOException) {
                    if (partBytes > 0 || ++attempt > 1) throw e
                }
            }
        }

        private fun open(path: String): HttpURLConnection {
            val conn = URL("$baseUrl/models/$model:$path").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = READ_TIMEOUT_MS
            conn.doOutput = true
            conn.setRequestProperty("x-goog-api-key", keys.get())
            conn.setRequestProperty("content-type", "application/json")
            return conn
        }

        private fun checkResponse(conn: HttpURLConnection): Unit {
            val code = conn.responseCode
            if (code in 200..299) return
            val resp = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code == 429) {
                val info = com.maya.assistant.ai.GeminiClient.parseError(resp, conn.getHeaderField("Retry-After"))
                blockedUntil = System.currentTimeMillis() + (info.retryAfterSec ?: 60) * 1000L
            }
            throw TtsHttpException(code)
        }

        private fun streamSynth(key: String, text: String, onPcm: (ByteArray) -> Unit) {
            val conn = open("streamGenerateContent?alt=sse")
            try {
                conn.outputStream.use { it.write(requestBody(text).toByteArray(Charsets.UTF_8)) }
                checkResponse(conn)
                var carry: Byte? = null
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        var bytes = parsePcmOrNull(line.removePrefix("data:").trim()) ?: continue
                        if (carry != null) { bytes = byteArrayOf(carry!!) + bytes; carry = null }
                        if (bytes.size % 2 == 1) { carry = bytes.last(); bytes = bytes.copyOf(bytes.size - 1) }
                        if (bytes.isNotEmpty()) onPcm(bytes)
                    }
                }
            } catch (e: Exception) {
                conn.disconnect(); throw e
            }
            // Success: the stream was read to the end, so the socket returns to the keep-alive pool (no new TLS handshake).
        }

        /** Non-streaming backup, for models/endpoints that reject streamGenerateContent. */
        private fun synthOnce(key: String, text: String): ByteArray {
            val conn = open("generateContent")
            try {
                conn.outputStream.use { it.write(requestBody(text).toByteArray(Charsets.UTF_8)) }
                checkResponse(conn)
                return parsePcm(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            } catch (e: Exception) {
                conn.disconnect(); throw e
            }
        }

        private fun requestBody(text: String): String = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject()
                .put("text", "Say warmly and naturally, like a friendly person talking: $text")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                    .put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
            .toString()
    }

    private class TtsHttpException(val code: Int) : IOException("tts http $code")

    /** Loudness per 40 ms window for chunks arriving incrementally; read by playback position for lip sync. */
    private class EnvelopeTracker {
        private val values = ArrayList<Float>()
        private var carry = ByteArray(0)
        @Synchronized fun add(chunk: ByteArray) {
            val all = carry + chunk
            val usable = all.size - all.size % (ENV_WINDOW * 2)
            if (usable > 0) values += envelope(all.copyOf(usable)).toList()
            carry = all.copyOfRange(usable, all.size)
        }
        @Synchronized fun at(frame: Int): Float = values.getOrElse(frame / ENV_WINDOW) { if (carry.isNotEmpty()) 0.5f else 0f }
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash-preview-tts"
        const val DEFAULT_VOICE = "Aoede"
        const val SAMPLE_RATE = 24_000
        private const val MAX_CHUNK = 700
        /** Remainder longer than this is read by the system voice (saves TTS quota). */
        private const val MAX_REST = 1_400
        private const val CONNECT_TIMEOUT_MS = 3_000
        /** Max wait for the first audio / between audio chunks before switching to the backup voice. */
        private const val READ_TIMEOUT_MS = 6_000
        private const val PREBUFFER_FRAMES = SAMPLE_RATE / 8 // 125 ms
        /** One loudness sample per 40 ms of audio. */
        const val ENV_WINDOW = SAMPLE_RATE / 25

        /** Loudness (RMS) per [ENV_WINDOW] samples of 16-bit little-endian PCM, normalised to 0..1 with a noise floor. */
        fun envelope(pcm: ByteArray, window: Int = ENV_WINDOW): FloatArray {
            val n = pcm.size / 2
            val rms = FloatArray((n + window - 1) / window)
            for (w in rms.indices) {
                val from = w * window
                val to = minOf(n, from + window)
                var sum = 0.0
                for (i in from until to) {
                    val v = (pcm[2 * i + 1].toInt() shl 8) or (pcm[2 * i].toInt() and 0xFF)
                    sum += v.toDouble() * v
                }
                rms[w] = if (to > from) (sqrt(sum / (to - from)) / 32768.0).toFloat() else 0f
            }
            val peak = rms.maxOrNull() ?: 0f
            if (peak <= 0f) return rms
            return FloatArray(rms.size) { val x = rms[it] / peak; if (x < 0.1f) 0f else x }
        }

        /** Splits on sentence boundaries into chunks small enough for fast TTS responses. */
        fun chunk(text: String): List<String> {
            val out = mutableListOf<String>()
            val cur = StringBuilder()
            for (s in text.split(Regex("(?<=[.!?])\\s+"))) {
                if (cur.isNotEmpty() && cur.length + s.length > MAX_CHUNK) { out += cur.toString(); cur.clear() }
                var part = s
                while (part.length > MAX_CHUNK) { out += part.take(MAX_CHUNK); part = part.drop(MAX_CHUNK) }
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(part)
            }
            if (cur.isNotBlank()) out += cur.toString()
            return out.ifEmpty { listOf(text) }
        }

        /** Like [parsePcm] for one SSE chunk: null when the chunk carries no audio (e.g. a final usage-only event). */
        fun parsePcmOrNull(json: String): ByteArray? = try { parsePcm(json) } catch (e: Exception) { null }

        /** Extracts base64 16-bit PCM (24 kHz mono) from a generateContent response. */
        fun parsePcm(json: String): ByteArray {
            val parts = JSONObject(json).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            for (i in 0 until parts.length()) {
                val data = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
                if (data.isNotEmpty()) return Base64.getDecoder().decode(data)
            }
            error("no audio in response")
        }
    }
}
