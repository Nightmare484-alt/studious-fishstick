package com.maya.assistant.ai

import com.maya.assistant.data.ChatMessage

enum class ChatError {
    MISSING_KEY, UNAUTHORIZED, RATE_LIMITED, OVERLOADED, BAD_REQUEST, SERVER, NETWORK, TIMEOUT, BAD_RESPONSE, UNKNOWN
}

/**
 * [retryAfterSec] is the wait the provider asked for (Retry-After header or RetryInfo), [detail] its own error
 * message, and [quotaExhausted] means a per-day quota is used up, so retrying soon cannot help.
 */
class ChatException(
    val error: ChatError,
    cause: Throwable? = null,
    val retryAfterSec: Int? = null,
    val detail: String? = null,
    val quotaExhausted: Boolean = false,
) : Exception(error.name, cause)

class ChatRequest(
    val system: String,
    val history: List<ChatMessage>,
    val userText: String,
    val image: ByteArray?,
    val model: String,
    val apiKey: String,
    val webSearch: Boolean,
)

/** A model returned by the provider's model-list endpoint. [id] is what generate requests use. */
data class ModelInfo(val id: String, val displayName: String)

interface ChatClient {
    /** Returns the assistant's reply text or throws [ChatException]. */
    suspend fun send(request: ChatRequest): String

    /** Like [send] but calls [onDelta] with each piece of text as it arrives. Default: one piece at the end. */
    suspend fun sendStreaming(request: ChatRequest, onDelta: (String) -> Unit): String =
        send(request).also(onDelta)

    /** Lists chat-capable models available to [apiKey]. Doubles as the connection/auth test. */
    suspend fun listModels(apiKey: String): List<ModelInfo> = throw ChatException(ChatError.UNKNOWN)

    /** Sends one tiny real request to [model]; throws [ChatException] if it fails. */
    suspend fun testModel(apiKey: String, model: String) {
        send(ChatRequest("Reply with the single word OK.", emptyList(), "Say OK.", null, model, apiKey, false))
    }
}
