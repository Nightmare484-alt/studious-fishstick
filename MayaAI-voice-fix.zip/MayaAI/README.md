# Maya AI

A voice-first Android assistant with the Maya character: tap to talk, show her a photo or your screen, ask her
to open apps, and she answers using the Google Gemini API. Native Kotlin + Jetpack Compose, minSdk 26 (Android 8.0),
targetSdk 34.

> **Build status: NOT yet built or tested.** The code was written in an environment with no Android SDK,
> Gradle, Kotlin compiler or network access, so nothing has been compiled and no test has been run.
> Expect a few compile errors on the first build. Run the build, then fix what Gradle reports.

## What works (by design) and what is a fallback

| Feature | Implementation | Status |
|---|---|---|
| Tap to Talk | Android `SpeechRecognizer` (live transcript) + `TextToSpeech` replies | Written, untested on device |
| Type instead | Keyboard button in the reply bubble (also the fallback if the mic is denied/unavailable) | Written |
| AI chat, coding help | Gemini `generateContent` API over `HttpURLConnection`, last 20 messages as context | Written |
| Web and research | Optional toggle: Gemini Google Search grounding tool | Written; needs a key/plan with web search enabled |
| See & Understand: Camera | **Fallback:** opens the system camera app (no CAMERA permission), downsizes the photo, sends it | Written |
| See & Understand: Screen | `MediaProjection` foreground service that takes **one** screenshot ~5 s after you allow it | Written; see limitations |
| Open apps | "Open WhatsApp" (offline matching) or the Apps sheet; no QUERY_ALL_PACKAGES | Written |
| Files | **Fallback:** system picker, plain-text files only (first 20,000 characters) | Written |
| Smart automation | Offline commands: open app, YouTube search, Google search, timer (hands off to the Clock app), remember | Written |
| Always learning | **Fallback:** explicit memory only: "remember that …", viewable and deletable | Written |

## Not implemented
- Controlling other apps' UI (tapping, typing in WhatsApp, etc.). That needs an Accessibility Service, which was
  left out on purpose (broad permission). "Open an app" only launches it.
- Continuous screen sharing/streaming. Only a single screenshot per tap.
- Wake word / always-listening. The mic is used only after you tap.
- Reminders/alarms at exact times (would need `SCHEDULE_EXACT_ALARM`). Timers go through the Clock app.
- Reading PDFs/Word files, gallery picker, multiple chats, the light "hoodie" theme from the reference screens.
- Instrumented (on-device) UI tests. Only JVM unit tests are included.

## 1. Get an API key
1. Create a free key at https://aistudio.google.com/apikey.
2. Open the app, tap **Settings** (gear), paste it into **API key**, tap **Save key**.

The key is encrypted with an Android Keystore AES key and kept in app-private storage. It is never in the source,
never in the APK, and is sent only to `generativelanguage.googleapis.com` in the `x-goog-api-key` header. `allowBackup` is off so it
isn't copied to cloud backups. **Model** defaults to `gemini-flash-latest`; Settings > Refresh models lists what your key can use, and you can pick one there.

## 2. Permissions, in plain terms
Declared in the manifest: `INTERNET`, `RECORD_AUDIO`, `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION`.
Not declared: camera, storage, contacts, location, all-apps list, overlay, accessibility, notifications.

**Microphone.** Requested only when you first tap Tap to Talk.
- Allow → listening starts (your phone's speech service does the transcription; on many phones that is Google's and may use the network).
- Deny once → next tap explains why, then asks again.
- Deny twice / "don't ask again" → Maya tells you it's blocked and offers **Open settings**. Typing always still works.

**Screen sharing.** Tap **Screen**:
1. Maya explains what will happen. Tap **Continue**.
2. Android shows its own screen-capture prompt (on Android 14+ you can choose "A single app" or "Entire screen").
3. After you allow it, a short-lived foreground service starts (required by Android for screen capture) with a notification.
4. Switch to the screen you want her to see. About 5 seconds later it takes **one** screenshot, sends it to the AI with the
   question "what's on my screen?", then the service stops itself. Nothing is recorded or saved to storage.
Declining or any failure shows a clear message and sends nothing.

**Camera.** Tap **Camera** to open your normal camera app; the photo it returns is sent to the AI and then deleted from the app cache.

## 3. Build in Termux

```bash
# one time (installs JDK 17, aapt2, Gradle 8.10.2, Android platform 34; needs ~2.5 GB and Wi-Fi)
cd MayaAI
chmod +x scripts/*.sh
./scripts/termux-setup.sh

# every build: runs unit tests, then builds the debug APK
./scripts/build-termux.sh

# APK only (faster, uses less RAM)
./scripts/build-termux.sh :app:assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk` (also copied to `Downloads/MayaAI-debug.apk` if you ran
`termux-setup-storage`). Install it by opening it from the Files app (allow "install unknown apps" for that app), or `termux-open app/build/outputs/apk/debug/app-debug.apk`.

Notes for phones: close other apps while building; the first build downloads ~500 MB of dependencies and can take
10+ minutes. If Gradle is killed or says "out of memory", lower `org.gradle.jvmargs` in `gradle.properties` to
`-Xmx1024m`, or build APK-only. The debug APK is signed automatically with a debug key.

**Release APK (optional).** Create a keystore with `keytool`, then:
```bash
./scripts/build-termux.sh :app:assembleRelease -PMAYA_KEYSTORE=$HOME/maya.jks \
  -PMAYA_KEYSTORE_PASSWORD=... -PMAYA_KEY_ALIAS=maya -PMAYA_KEY_PASSWORD=...
```
Without those properties the release APK is unsigned and can't be installed.

**If Termux can't build it:** the AGP-on-Termux route depends on the Termux `aapt2` build matching the Android
Gradle Plugin. If you see aapt2 errors, push the folder to a GitHub repo; `.github/workflows/build.yml` builds the APK
in the cloud and lets you download it from the run's artifacts.

## 4. Tests
`./scripts/build-termux.sh :app:testDebugUnitTest` (or `gradle :app:testDebugUnitTest`). JVM tests cover:
- Memory store: persistence, dedupe, size limits, delete/clear, corrupt-file recovery.
- Permission decision logic (first ask / rationale / blocked) and speech-error mapping.
- API request building (history, image, web search, key never in body), response parsing, HTTP status → error mapping.
- ViewModel flows with fakes: missing key, network/auth errors, history handling, local commands vs. AI fallback,
  remember/forget, voice transcript → AI, mic denied vs. blocked, screen-capture success/denied/failure, delete-all-data.

## 5. Known limitations
- **Untested on a device**; speech, TTS, camera and screen capture behave differently across phones.
- Apps that mark windows secure (banking, some video apps) produce a black or failed screenshot.
- The first frame of a screenshot can occasionally be stale; tap Screen again.
- Voice recognition quality and offline support depend on the phone's speech service; some devices need internet.
- Web search is billed by your provider; leave the toggle off if you don't want that.
- Anything you say or share is sent to the AI provider to produce an answer; see their privacy policy. Memory notes are also sent.
- The reference "Maya" artwork is bundled (hero image and 5 expression faces cut from your character sheet). The hero
  image has a light grey-blue background that is darkened in-app; replace `app/src/main/res/drawable-nodpi/maya_hero.webp` with a
  clean dark-background render for the best look.
- Package name `com.maya.assistant` and the generated "M" logo are placeholders.

## Layout
```
app/src/main/java/com/maya/assistant/
  MainActivity.kt        permission, camera, screen-share and file flows
  vm/                    MayaViewModel, UI state, permission decision logic
  ai/                    Gemini client, system prompt
  voice/                 SpeechRecognizer + TextToSpeech wrappers
  capture/               one-shot screen capture service, image helpers
  actions/               offline command router, app launcher
  data/                  Keystore key storage, settings, memory
  ui/                    Compose screens and theme
```
